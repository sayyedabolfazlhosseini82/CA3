#include "all.h"
void cpy_chars(char *input, char *inst, char *data_1, char *data_2){/*This function shows the copying of characters and this function is also used in other functions and is one of the basic functions in the third project.*/
	int i,j1=0,j2=0,j3=0;
	int array_num = 0;
	for(i=0; input[i] ;i++){
		if ( input[i] == ' '){
			array_num++;
		}
		else if(array_num == 0){
			inst[j1] = input[i];
			j1++;
		}
		else if(array_num == 1){
			data_1[j2] = input[i];
			j2++;
		}
		else if(array_num == 2){
			data_2[j3] = input[i];
			j3++;
		}
		else if(array_num == 3){
			printf("invalid input!\n");
			return;
		}
	}
	inst[j1] = 0;
	data_1[j2] = 0;
	data_2[j3] = 0;
}
void copy_chars2f(char *first, char *chars){/*This function shows the copying of characters in a different way and this function is also used in other functions and is one of the basic functions in the third project.*/
	int i;
	for(i=0; chars[i] ;i++){
		first[i] = chars[i];
	}
	first[i] = 0;
}
