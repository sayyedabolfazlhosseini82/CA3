#include "all.h"

int main(){
	int instruction_num = 0;
	account *acnt = (account *) malloc(sizeof(account));
	acnt->user_name = (char *) malloc(2 * sizeof(char));
	acnt->user_name[0] = 0;
	acnt->password = (char *) malloc(2 * sizeof(char));
	acnt->password[0] = 0;
	acnt->posts_num = 0;
	acnt->pst = 0;
	acnt->next = 0;
	account *acnt_ptr = 0;
	//instruction_num = instruction();
	while(1){
		acnt_ptr = instruction(acnt, acnt_ptr);
	}
	return 0;
}



