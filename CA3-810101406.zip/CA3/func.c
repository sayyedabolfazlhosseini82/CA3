#include "all.h"

account * instruction(account *acnt, account *acnt_ptr){
	char input[2103];
	input[0] = 0;
	char inst[101];
	inst[0] = 0;
	char data_1[1001];
	data_1[0] = 0;
	char data_2[1001];
	data_2[0] = 0;
	printf("Please enter your instruction: ");
	scanf(" %[^\n]%*c",input);
	cpy_chars(input, inst, data_1, data_2);
	//printf("%s\n",input);
	//printf("%s\n",inst);
	//printf("%s\n",data_1);
	//printf("%s\n",data_2);
	if ( same_chars(inst,"signup") ){
		signup(acnt, data_1, data_2);
	}
	else if ( same_chars(inst,"login") ){
		return login(acnt, acnt_ptr, data_1, data_2);
	}
	else if ( same_chars(inst,"post") ){
		post_send(acnt, acnt_ptr, data_1);
	}
	else if ( same_chars(inst,"like") ){
		like(acnt, acnt_ptr, data_1, data_2);
	}
	else if ( same_chars(inst,"logout") ){
		//logout(acnt, acnt_ptr);
		acnt_ptr = 0;
	}
	else if ( same_chars(inst,"delete") ){
		post_delete(acnt, acnt_ptr, data_1);
	}
	else if ( same_chars(inst,"info") ){
		info(acnt, acnt_ptr);
	}
	else if ( same_chars(inst,"find_user") ){
		find_user(acnt, acnt_ptr, data_1);
	}
	return acnt_ptr;
}

void like(account *acnt, account *acnt_ptr, char *data_1, char *data_2){/*The post id like function is the post number of the user who posted the post*/
	account * iter_acnt = acnt;
	post *iter_post = 0;
	int post_id = toint(data_2);
	while(iter_acnt){
		if ( same_chars(data_1, iter_acnt->user_name) ){
			iter_post = iter_acnt->pst;
			while(iter_post){
				if ( iter_post->post_id == post_id ){
					iter_post->like_num++;
					printf("done!\n\n");
					return;
				}
				iter_post = iter_post->next;
			}
			break;
		}
		iter_acnt = iter_acnt->next;
	}
	printf("rong user or post!\n\n");
}

void info(account *acnt, account *acnt_ptr){/*By means of this command, the information for the desired user is displayed,
that information consists of the user's name, password, posts made with id_post and the number of their likes.*/
	post *iter_post;
	if (!acnt_ptr){
		printf("first login!\n\n");
		return;
	}
	iter_post = acnt_ptr->pst;
	printf("\nuser_name: %s\n", acnt_ptr->user_name);
	printf("password: %s\n", acnt_ptr->password);
	while(iter_post){
		printf("post_id: %s\t", iter_post->post_id);
		printf(",like_num: %s\n", iter_post->like_num);
		iter_post = iter_post->next;
	}
	printf("\n");
}

void find_user(account *acnt, account *acnt_ptr, char *data_1){/*The username must be completely correct for the search to take place,
otherwise a message for the search failure will be displayed*/
	account * iter_acnt = acnt;
	post *iter_post;
	while(iter_acnt){
		if ( same_chars(data_1, iter_acnt->user_name) ){
			iter_post = iter_acnt->pst;
			printf("\nuser_name: %s\n", acnt_ptr->user_name);
			while(iter_post){
				printf("post_id: %s\t", iter_post->post_id);
				printf(",like_num: %s\n", iter_post->like_num);
				iter_post = iter_post->next;
			}
			printf("\n");
			return;
		}
		iter_acnt = iter_acnt->next;
	}
	printf("rong pass or user!\n\n");
}

int same_chars(char *inp,char *inst){/*This shows the same set of characters used in the functions above and includes the basic functions of the project.*/
	int i;
	for(i=0; inst[i] ;i++){
		if (inp[i] != inst[i]){
			return 0;
		}
	}
	if (inp[i]){
		return 0;
	}
	return 1;
}

int chars_len(char *chars){/*This function has different characters and this function is also used in other functions and is one of the basic functions in the third project.*/
	int i;
	for(i=0; chars[i] ;i++);
	return i;
}

int toint(char *inp){/*This function shows the conversion of character to number and is one of the basic functions*/
	int i;
	int out = 0;
	for(i=0; inp[i] ;i++){
		out = (out*10)+(inp[i]-48);
	}
	return out;
}