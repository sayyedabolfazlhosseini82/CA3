#include "define.h"
account * instruction(account *, account *);
void signup(account *, char *, char *);
account * login(account *, account *, char *, char *);
void post_send(account *, account *, char *);
void like(account *, account *, char *, char *);
void logout(account *, account *);
void post_delete(account *, account *, char *);
void info(account *, account *);
void find_user(account *, account *, char *);
int chars_len(char *chars);
int same_chars(char *,char *);
void cpy_chars(char *, char *, char *, char *);
void copy_chars2f(char *, char *);
int toint(char *);
