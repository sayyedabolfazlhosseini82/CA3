#include "all.h"
void post_send(account *acnt, account *acnt_ptr, char *data_1){/*Posting function where it should be text and the text of each post is also implemented using dynamic array.*/
	int ch_num;
	post *iter_post;
	if (!acnt_ptr){
		return;
	}
	if (!acnt_ptr->pst){
		acnt_ptr->pst = (post *) malloc(sizeof(post));
		iter_post = acnt_ptr->pst;
	}
	else{
		iter_post = acnt_ptr->pst;
		while(iter_post->next){
			iter_post = iter_post->next;
		}
		iter_post->next = (post *) malloc(sizeof(post));
		iter_post = iter_post->next;
	}
	iter_post->user_name = acnt_ptr->user_name;
	acnt_ptr->posts_num++;
	iter_post->post_id = acnt_ptr->posts_num;
	iter_post->like_num = 0;
	iter_post->next = 0;
	//txt
	ch_num = chars_len(data_1);
	iter_post->txt = (char *) malloc(ch_num * sizeof(char));
	copy_chars2f(iter_post->txt, data_1);
	printf("done!\n\n");
}
void post_delete(account *acnt, account *acnt_ptr, char *data_1){/*Each user can only delete her own posts, and that post can be removed from her posts (linked list) and removed from it.(feminine)*/
	account * this_acnt = acnt_ptr;
	post *iter_post = 0;
	post *befor_post = 0;
	int post_id = toint(data_1);
	if (!acnt_ptr){
		printf("first login!\n\n");
		return;
	}
	iter_post = this_acnt->pst;
	while(iter_post){
		if ( iter_post->post_id == post_id ){
			if (befor_post){
				befor_post->next = iter_post->next;
				free(iter_post);
			}
			else{
				this_acnt->pst = iter_post->next;
				free(iter_post->txt);
				free(iter_post);
			}
			printf("done!\n\n");
			return;
		}
		befor_post = iter_post;
		iter_post = iter_post->next;
	}
	printf("rong post_id!\n\n");
	return;
}