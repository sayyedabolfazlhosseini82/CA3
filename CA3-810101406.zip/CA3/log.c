#include "all.h"
void signup(account *acnt, char *data_1, char *data_2){/*It works by adding a member to the end of the linked list*/
	int ch_num;
	account * iter_acnt = acnt;
	while(iter_acnt->next){
		iter_acnt = iter_acnt->next;
	}
	iter_acnt->next = (account *) malloc(sizeof(account));
	iter_acnt = iter_acnt->next;
	ch_num = chars_len(data_1);
	iter_acnt->user_name = (char *) malloc(ch_num * sizeof(char));
	copy_chars2f(iter_acnt->user_name, data_1);
	ch_num = chars_len(data_2);
	iter_acnt->password = (char *) malloc(ch_num * sizeof(char));
	copy_chars2f(iter_acnt->password, data_2);
	iter_acnt->posts_num = 0;
	iter_acnt->pst = 0;
	iter_acnt->next = 0;
	printf("signup done!\n\n");
}
account * login(account *acnt, account *acnt_ptr, char *data_1, char *data_2){/*In this function, the PT post pointer,
which is defined in the main function, points to the logged in account, and in case of logout, the pointer becomes zero,
to post the account that is logged in, a new post is added to the end of the linked list of its posts. To delete posts,
the desired value is removed from this linked list, and the rest of the functions,
such as searching, are performed by scrolling through the linked list of accounts.
The functions of receiving input and working with strings are also specified in the code.*/
	account * iter_acnt = acnt;
	while(iter_acnt){
		if ( same_chars(data_1, iter_acnt->user_name) ){
			if ( same_chars(data_2, iter_acnt->password) ){
				printf("loged in!\n\n");
				return iter_acnt;
			}
			else{
				break;
			}
		}
		iter_acnt = iter_acnt->next;
	}
	printf("rong pass or user!\n\n");
	return acnt_ptr;
}
void logout(account *acnt, account *acnt_ptr){/*It was explained in the login function*/
	return;
}