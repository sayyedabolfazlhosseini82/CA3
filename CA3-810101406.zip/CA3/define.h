#include<stdio.h>
#include<stdlib.h>


typedef struct post{
	char *user_name;
	int post_id;
	int like_num;
	char *txt;
	struct post *next;
}post;
typedef struct account{
	char *user_name;
	char *password;
	int posts_num;
	post *pst;/*A pointer to a linked list*/
	struct account *next;/*A pointer for account posts that is added to the end of posts if the user makes a new post*/
}account;

